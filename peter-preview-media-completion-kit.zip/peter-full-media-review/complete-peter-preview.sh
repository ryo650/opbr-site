#!/usr/bin/env bash
set -euo pipefail
BRANCH="feat/peter-pre-release-guide-preview-20261020"
PACKAGE="${1:-}"
if [[ -z "$PACKAGE" || ! -f "$PACKAGE" ]]; then
  echo "Usage: $0 /absolute/path/to/peter-preview-media-completion-kit.zip" >&2
  exit 2
fi
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"
CURRENT="$(git branch --show-current)"
if [[ "$CURRENT" != "$BRANCH" ]]; then
  echo "Expected branch $BRANCH, got $CURRENT. Fetch and checkout the PR branch first." >&2
  exit 2
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo "Working tree not clean. Preserve or resolve changes first." >&2
  exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$PACKAGE" -d "$TMP"
if [[ -d "$TMP/peter-full-media-review/media" ]]; then
  MEDIA="$TMP/peter-full-media-review/media"
  PORTRAIT="$MEDIA/peter.webp"
elif [[ -d "$TMP/peter_pre_release/public" ]]; then
  MEDIA="$TMP/peter_pre_release/public/character-guides/the-five-elders-st-shepherd-ju-peter"
  PORTRAIT="$TMP/peter_pre_release/public/characters/black/the-five-elders-st-shepherd-ju-peter.webp"
else
  echo "Missing expected media package root" >&2
  exit 2
fi
GUIDE="src/data/character-guides/the-five-elders-st-shepherd-ju-peter.ts"
CHARACTERS="src/data/characters/black.ts"
[[ -f "$GUIDE" && -f "$CHARACTERS" ]] || { echo "Expected PR guide files missing" >&2; exit 2; }
mkdir -p public/characters/black public/character-guides/the-five-elders-st-shepherd-ju-peter
cp "$PORTRAIT" public/characters/black/the-five-elders-st-shepherd-ju-peter.webp
cp "$MEDIA"/*.mp4 public/character-guides/the-five-elders-st-shepherd-ju-peter/
python3 - <<'PY'
from pathlib import Path
import re
cpath=Path('src/data/characters/black.ts')
text=cpath.read_text()
old='/characters/black/the-five-elders-st-shepherd-ju-peter.svg'
new='/characters/black/the-five-elders-st-shepherd-ju-peter.webp'
assert old in text or new in text, 'Character portrait reference missing'
cpath.write_text(text.replace(old,new))
path=Path('src/data/character-guides/the-five-elders-st-shepherd-ju-peter.ts')
s=path.read_text()
root='/character-guides/the-five-elders-st-shepherd-ju-peter/'
sections=[
 ('"title": "Game-Changing Capture Pressure",','sp-capture.mp4'),
 ('"title": "Keep HP Above 50%",','capture-hp-50.mp4'),
]
for needle,filename in sections:
    assert needle in s, f'Could not find section: {needle}'
    pattern=re.compile(r'^(\s*)'+re.escape(needle)+r'\s*$',re.M)
    m=pattern.search(s)
    assert m
    line=m.group(0)
    video='"video": "'+root+filename+'",'
    if video not in s:
        s=s[:m.end()]+ '\n'+m.group(1)+video+s[m.end():]
for name,filename in [
 ('None of You Are Leaving Alive!','skill-1.mp4'),
 ("Godhead of Agriculture's Raid",'skill-2.mp4'),
]:
    target='"name": '+ __import__('json').dumps(name)+','
    assert target in s, f'Missing skill name: {name}'
    video='"video": "'+root+filename+'",'
    if video not in s:
        m=re.search(r'^(\s*)'+re.escape(target)+r'\s*\n(\s*)"cooldown": (\d+),',s,re.M)
        assert m, f'Missing cooldown field: {name}'
        insertion='\n'+m.group(2)+video
        s=s[:m.end()]+insertion+s[m.end():]
s=s.replace('Pre-Release Guide — Media Integration Pending','Pre-Release Guide')
s=s.replace('Early guide based on official pre-release reveals. Matchup ratings are predictions, not post-launch results. Temporary portrait and skill-video uploads are pending before final preview approval.','Based on official pre-release reveals. Gameplay interactions, matchups, and overall performance will be reviewed after the October 21, 2026 release.')
path.write_text(s)
PY
if [[ -f public/characters/black/the-five-elders-st-shepherd-ju-peter.svg ]]; then
 git rm -q public/characters/black/the-five-elders-st-shepherd-ju-peter.svg
fi
if command -v ffprobe >/dev/null 2>&1; then
  for file in public/character-guides/the-five-elders-st-shepherd-ju-peter/*.mp4; do
    ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height -of default=noprint_wrappers=1 "$file"
  done
fi
# Changed-file lint; global lint on the baseline currently fails in
# MedalFinderDetailsDialog.tsx, unrelated to the Peter changes.
npx eslint "$GUIDE" "$CHARACTERS" src/data/character-guides/index.ts
npx tsc --noEmit --incremental false
npm run build
git add "$GUIDE" "$CHARACTERS" public/characters/black/the-five-elders-st-shepherd-ju-peter.webp public/character-guides/the-five-elders-st-shepherd-ju-peter/
git commit -m "feat: add Peter pre-release portrait and gameplay clips"
git push origin "$BRANCH"
echo "Pushed media to Draft PR #111. Wait for Vercel Preview and validate video 200/playback. Do NOT merge yet."
