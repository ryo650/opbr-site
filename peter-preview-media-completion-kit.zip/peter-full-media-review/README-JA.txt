ピーター聖ガイド：動画付きローカル確認版

ZIPを展開し、index.htmlをブラウザで開いてください。サイトと同じCSSではなく、素材と英語文章を確認するためのページです。
GitHub Draft PR: https://github.com/ryo650/opbr-site/pull/111
Vercelでは現時点で動画が未反映です。
